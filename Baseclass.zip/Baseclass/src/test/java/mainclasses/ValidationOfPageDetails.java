package mainclasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import baseclass.BrowserStarting;
import baseclass.PageOObjectModel;

import java.time.Duration;

public class ValidationOfPageDetails {
    SoftAssert soft = new SoftAssert();
    BrowserStarting browser = new BrowserStarting();
    WebDriver driver;

    @BeforeMethod
    public void startbrowser() throws Exception {
        driver = browser.startthebrowser();
    }

    @Test
    public void validatePageDetails() throws Exception {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageOObjectModel page = new PageOObjectModel();
        

        // ----- Placeholder validation -----
        WebElement input = driver.findElement(page.txtNumber);
        input.sendKeys("4");
        wait.until(ExpectedConditions.attributeToBe(input, "value", "4"));
        String actualValue = input.getAttribute("value");
        Assert.assertEquals(actualValue, "4");
        
         
        // ----- TITLE VALIDATION -----
        String actualTitle = driver.getTitle();
        System.out.println("Actual Title: " + actualTitle);
        soft.assertTrue(actualTitle.contains("Factorial"));


        // ----- URL VALIDATION -----
        String actualUrl = driver.getCurrentUrl();
        System.out.println("Actual URL: " + actualUrl);
        soft.assertTrue(actualUrl.contains("httpss"));
        soft.assertAll();
        
        
               
    }
    @AfterMethod
    public void closebrowser() {
    	browser.closebrowser();
    	
    }
    
}
