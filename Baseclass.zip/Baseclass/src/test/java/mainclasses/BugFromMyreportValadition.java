package mainclasses;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import baseclass.BrowserStarting;
import baseclass.PageOObjectModel;

public class BugFromMyreportValadition {
	SoftAssert soft = new SoftAssert();
	WebDriver driver;
	BrowserStarting browser = new BrowserStarting();

	@BeforeMethod
	public void startbrowser() throws Exception {
		driver = browser.startthebrowser();
	}

	@Test
	public void testing() throws Exception {
		PageOObjectModel page = new PageOObjectModel();
		driver.findElement(page.linkPrivacy).click();
		String url1 = driver.getCurrentUrl().toLowerCase();
		soft.assertTrue(url1.contains("terms"));
		Thread.sleep(1000);

		driver.navigate().back();
		Thread.sleep(1000);

		driver.findElement(page.linkTerms).click();
		String url2 = driver.getCurrentUrl().toLowerCase();
		soft.assertTrue(url2.contains("privacy"));
		soft.assertAll();
	}

	@AfterMethod
	public void closebrowser() {
		browser.closebrowser();
	}

}
