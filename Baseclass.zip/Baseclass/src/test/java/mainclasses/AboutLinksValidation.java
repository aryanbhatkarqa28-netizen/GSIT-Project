package mainclasses;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import baseclass.BrowserStarting;
import baseclass.PageOObjectModel;

public class AboutLinksValidation {

	  WebDriver driver;
	    BrowserStarting browser = new BrowserStarting();

	    @Parameters("browser")
	    @BeforeMethod
	    public void startbrowser(@Optional("chrome") String browserName) throws Exception {
	        driver = browser.startthebrowser(browserName);
	}

	@Test
	public void aboutPageLinkVerification() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageOObjectModel page = new PageOObjectModel();
		WebElement about = driver.findElement(page.linkAbout);
		List<WebElement> links = driver.findElements(By.tagName("a"));
		System.out.println("Links on About page:");
		for (WebElement link : links) {
			System.out.println(link.getText());
			
			

		}
		System.out.println("*******************************************************");
		wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.tagName("a"), 5));
	}

	@AfterMethod
	public void closebrowser() {
    	browser.closebrowser();
	}
}
