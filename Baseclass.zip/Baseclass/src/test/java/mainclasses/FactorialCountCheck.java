package mainclasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import baseclass.PageOObjectModel;
import jxl.Sheet;
import jxl.Workbook;
import java.io.FileInputStream;

public class FactorialCountCheck {

    @Test(dataProvider = "factorialData")
    public void verifyFactorial(String number, String expectedResult) throws Exception {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://qainterview.pythonanywhere.com/");

        PageOObjectModel page = new PageOObjectModel();

        // ENTER NUMBER
        driver.findElement(page.txtNumber).clear();
        driver.findElement(page.txtNumber).sendKeys(number);

        // CLICK CALCULATE
        driver.findElement(page.btnCalculate).click();

        Thread.sleep(1500);

        // FETCH WEBSITE RESULT
        String fullText = driver.findElement(page.resultLabel).getText();
        // Example: "The factorial of 5 is: 120"

        // ---- FIX: take text AFTER the last ':' then remove non-digits ----
        String afterColon;
        if (fullText.contains(":")) {
            String[] parts = fullText.split(":");
            afterColon = parts[parts.length - 1];        // last piece after the colon
        } else {
            afterColon = fullText;                       // fallback
        }

        // remove anything that's not a digit (commas, spaces, words)
        String actualResult = afterColon.replaceAll("[^0-9]", "").trim();

        // DEBUG prints (helps see what's being compared)
        System.out.println("Input number   : " + number);
        System.out.println("Full website text: \"" + fullText + "\"");
        System.out.println("Text after colon : \"" + afterColon + "\"");
        System.out.println("Actual result    : " + actualResult);
        System.out.println("Expected result  : " + expectedResult);

        // COMPARE
        Assert.assertEquals(actualResult, expectedResult, "Mismatch for number: " + number);

        driver.quit();
    }

    // ------------ EXCEL READER -------------
    @DataProvider(name = "factorialData")
    public Object[][] getData() throws Exception {

        FileInputStream fis = new FileInputStream("C:\\Users\\aryan\\Downloads\\factorial_data.xls");
        Workbook wb = Workbook.getWorkbook(fis);
        Sheet sheet = wb.getSheet(0);

        int rows = sheet.getRows();
        int cols = sheet.getColumns();

        Object[][] data = new Object[rows - 1][cols];

        for (int i = 1; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                data[i - 1][j] = sheet.getCell(j, i).getContents();
            }
        }

        wb.close();
        fis.close();

        return data;
    }
}