package mainclasses;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.v114.browser.Browser;
import org.testng.Assert;

import baseclass.BrowserStarting;
import baseclass.PageOObjectModel;

public class UiValidation {
	WebDriver driver;

	BrowserStarting browser = new BrowserStarting();
	 @Parameters("browser")
	    @BeforeMethod
	    public void startbrowser(@Optional("chrome") String browserName) throws Exception {
	        driver = browser.startthebrowser(browserName);
	}

	@Test
	public void Validationofuielements() {
		PageOObjectModel page = new PageOObjectModel();

		// TEXTBOX

		WebElement textbox = driver.findElement(page.txtNumber);
		Assert.assertEquals(textbox.isDisplayed(), true);
		Assert.assertEquals(textbox.isEnabled(), true);

		// CALCULATE BUTTON

		WebElement calcBtn = driver.findElement(page.btnCalculate);
		Assert.assertEquals(calcBtn.isDisplayed(), true);
		Assert.assertEquals(calcBtn.isEnabled(), true);

		// ABOUT LINK

		WebElement about = driver.findElement(page.linkAbout);
		Assert.assertEquals(about.isDisplayed(), true);

		// TERMS LINK

		WebElement terms = driver.findElement(page.linkTerms);
		Assert.assertEquals(terms.isDisplayed(), true);

		// PRIVACY LINK

		WebElement privacy = driver.findElement(page.linkPrivacy);
		Assert.assertEquals(privacy.isDisplayed(), true);

		System.out.println("UI Validation Completed Successfully!");

	}

	@AfterMethod
	public void close() {
		browser.closebrowser();
	}

}
