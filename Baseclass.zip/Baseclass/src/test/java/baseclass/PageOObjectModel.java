package baseclass;

import org.openqa.selenium.By;

public class PageOObjectModel {
 
	
	 public By txtNumber = By.xpath("//*[@name='number']");
     public By btnCalculate = By.xpath("//*[text()='Calculate!']");
     public By linkAbout = By.xpath("//*[text()='About']");
     public By linkTerms = By.xpath("//*[text()='Terms and Conditions']");
     public By linkPrivacy = By.xpath("//*[text()='Privacy']");
     public By resultLabel = By.xpath("//*[@id='resultDiv']");


	
}
